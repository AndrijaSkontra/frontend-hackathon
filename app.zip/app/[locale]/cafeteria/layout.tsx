export default function CafeteriaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
